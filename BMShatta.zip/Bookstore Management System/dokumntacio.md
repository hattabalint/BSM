﻿Rendben, lefordítom a teljes dokumentumot. A fordítás hosszabb ideig tarthat, mert a dokumentum terjedelmes. Az alábbiakban a következő részek fordítása található:

-----
**Összefoglaló**

A könyvesbolt-menedzsment rendszer egy webes alkalmazás létrehozására szolgál, amely segít az embereknek megtalálni és megvásárolni a legújabb könyveket különböző kategóriákban, mint például életrajz, programozás, menedzsment stb. Hasznos abban, hogy egyszerűbbé teszi a személyes könyvvásárlást.

Manapság a legtöbb könyvesbolt online vásárlási lehetőségeket kínál. Az adminisztrátoroknak azonban sok papírmunkájuk van, és gyakran használják a desktop alkalmazásokat, mint például az Excel-t, hogy kezeljék a felhasználók adatait. A javasolt könyvesbolt-rendszer szerveren fut, és a felhasználók az összes regisztrációs tevékenységet kezelhetik.

Ez az alkalmazás központosított adatbázist használ, így minden helyszíni változtatás azonnal megjelenik. Mivel ez egy online eszköz, több felhasználó is bejelentkezhet és egyszerre használhatja a rendszert.

A projekt célja a kézi műveletek szükségességének csökkentése, amelyekkel különböző tranzakciókat és történeti adatokat kezelnek. Az alkalmazás felületet biztosít a felhasználóknak a részletek és a könyvesbolt felépítésének megtekintéséhez.

-----
**1. Fejezet: Bevezetés**

**1.1 Projekt háttere**

Ez a szoftver lehetővé teszi az adminisztrátor számára a könyv és ügyféladatok tárolását. Egyszerű hozzáférést biztosít olyan információkhoz, mint például az ügyfél adatai és a könyvek elérhetősége. Csökkenti a papírmunkát és digitalizálja a rendszert.

**1.2 A projekt céljai**

- A papírmunka csökkentése.
- A rendszer számítógépesítése.
- A működési sebesség növelése.
- Gyorsabb keresés és nagyobb pontosság.
- Nagy mennyiségű adat tárolása adatbázisokban.
- Az értékesítés nyomon követése egyszerűbbé válik.

**1.3 A projekt célja**

A könyvesbolt-menedzsment rendszer célja, hogy megoldja a papírmunkával kapcsolatos problémákat, és lehetővé tegye az adminisztrátor számára, hogy egyszerre több műveletet is végrehajtson egy helyen. A rendszer megőrzi a könyvekkel kapcsolatos adatokat, és a felhasználóbarát felület biztosítja a könnyű kezelhetőséget.

**1.4 A projekt hatóköre**

A rendszer célja, hogy csökkentse a túlóra kifizetéseket, és növelje a kezelt rekordok számát, biztosítva a pontos és gyors keresést. Az ügyfelek néhány kattintással lefoglalhatnak egy könyvet, az adminisztrátor pedig hatékonyan kezelheti az adatbázist.

**1.5 A projekt alkalmazhatósága**

- Azoknak az ügyfeleknek, akik bárhol és bármikor szeretnének könyveket vásárolni.
- Az adminisztrátorok számára, akik könyveket szeretnének hozzáadni az adatbázishoz.

**2. Fejezet: Követelmények és elemzés**

**2.1 Probléma megfogalmazása**

- Túl sok papírmunka.
- Az eljárás sok időt igényel.
- Extra költségek a papírmunkával kapcsolatban.
- Nagy mennyiségű adat tárolása.
- Nehézkes manuális adatkezelés.
- Jelentések készítése heti, havi, éves bontásban nehézségekbe ütközik.
- A kézi rendszer lassú és pontatlan.
- A személyes keresés időigényes.
- Nehézkes egy adott rekord keresése a kézi rendszerben.

**2.2 Követelmények specifikációja**

A rendszer két modult tartalmaz:

**1) Adminisztrátor modul:**

- Kategória hozzáadása.
- Kategórialista megtekintése.
- Új könyv hozzáadása.
- Könyv megtekintése.
- Üzenetek megtekintése, amelyeket az ügyfelek küldenek.

**2) Ügyfél modul:**

- Könyvek megtekintése.
- Könyvek hozzáadása a kosárhoz.
- Könyvek keresése.
- Kosár megtekintése vagy könyvek hozzáadása.

**2.3 Hardver követelmények**

- 32 bites operációs rendszer.
- Windows 7/8/8.1/10, Linux Ubuntu, Mac OS.
- 350 MB RAM.

**2.4 Szoftver követelmények**

- WAMP Server.
- MySQL.
- Böngésző.
- PHPMyAdmin.
- Kliens oldali eszközök.
- Kétszeres processzor vagy annál magasabb (ajánlott: 2,20 GHz).
- 512 MB RAM vagy több.
- 45 MB szabad hely a rendszermeghajtón.
- Operációs rendszer: Windows vagy nyílt forráskódú 32/64 bites operációs rendszer.
- Mozilla Firefox 2.0, Internet Explorer 8.0, Google Chrome böngészők.

**2.5 Tervezés és ütemezés**

Különböző időtartamokra van szükség a projektciklus különböző szakaszaiban, a helyzet tényezőitől függően. Az előzetes fejlesztési szakaszban gyűjtött információk hatással vannak a követelmény-elemzésre, és a tervezési szakaszban használják fel őket.

**Ütemezés:**

|**Feladat**|**Kezdés/Befejezés**|**Időtartam**|
| :-: | :-: | :-: |
|Elemzés|2018\.12.25 - 2019.01.01|8 nap|
|Tervezés|2019\.01.01 - 2019.01.09|9 nap|
|Kódolás|2019\.01.10 - 2019.02.08|4 hét|
|Implementáció|2019\.02.08 - 2019.02.12|5 nap|
|Tesztelés|2019\.02.12 - 2019.02.17|6 nap|
|Dokumentálás|2019\.02.18 - 2019.03.10|3 hét|

A fenti ütemezés meghatározza a szoftverfejlesztés különböző fázisaiban szükséges becsült időtartamot. A csapattagok technikailag készen állnak, néhány napos képzés után elérhetik a technológiai ismereteket. Az ütemterv minden fázis végén felülvizsgálatra és szükség esetén frissítésre kerül.

-----
**3. Fejezet: Rendszertervezés**

**3.1 Átfogó rendszertervezés tervezési eszközökkel**

A tervezési fázis célja, hogy megoldást találjon a követelményekben meghatározott problémára. A rendszertervezés célja az adott modulok azonosítása, a specifikációk kidolgozása, valamint az interfészek és adatfolyamok megtervezése. A cél, hogy olyan modellt hozzunk létre, amely később a rendszer felépítéséhez használható.

A rendszertervezés két szakaszból áll:

1. Fizikai tervezés.
1. Adatbázis-tervezés.

**Fizikai tervezés**

A fizikai tervezés egy grafikus ábrázolása a rendszer belső és külső entitásainak, valamint az adatok be- és kimenetének ábrázolása. Az entitások közötti adatáramlás megjelenítéséhez adatfolyam-diagramokat (DFD) használunk.

**Adatfolyam-diagram (DFD)**

Az adatfolyam-diagramok (DFD) grafikus ábrázolásai az adatok áramlásának egy információs rendszeren keresztül. Az adatfolyam-diagramok az elemzők számára egy átfogó képet nyújtanak arról, hogyan működik a rendszer és milyen adatokat kezel. A DFD előnye, hogy megmutatja, milyen adatokat dolgoz fel a rendszer, milyen átalakításokat végez az adatokon, mely adatok kerülnek tárolásra, és hogyan kerülnek felhasználásra.

**DFD szabványos szimbólumai:**

|**Szimbólum**|**Név**|**Funkció**|
| :-: | :-: | :-: |
|Adatfolyam|Az adatok áramlását mutatja a folyamatok között.||
|Folyamat|Egy adott átalakítás végrehajtása az adatokat illetően.||
|Input/Output|Adatok be- és kimenetének szimbóluma.||
**0. szintű DFD (Honlap folyamatábrája)**

(Ez az ábra az online könyvesbolt adatáramlását mutatja be.)

**1. szintű DFD (Részletes folyamatábra)**

|**Felhasználó**|**Könyv kiválasztása**|**Adatok feldolgozása**|**Sikeres megrendelés**|
| :-: | :-: | :-: | :-: |
|Könyvek hozzáadása a kosárhoz|Adatok feldolgozása|Rendelés részletei|Könyvlista kiválasztása|

**Folyamatábra**

**Felhasználói folyamatábra**

(Ez az ábra bemutatja a felhasználói útvonalakat a rendszerben.)

**Használati eset diagram**

A használati eset diagramok a felhasználó és a rendszer közötti interakciókat ábrázolják. A diagram két fő eleme a használati esetek és a szereplők (felhasználók vagy rendszerek, amelyek kapcsolatba lépnek a vizsgált rendszerrel).

**BMS Használati eset diagram**

Könyvesbolt-menedzsment rendszer:

- Termék megtekintése.
- Megrendelés leadása.
- Kosárba helyezés.
- Regisztráció.
-----
**3.2 Adatszótár**

**Adatbázis-tervezés és szerkezet kialakítása**

Az alábbiakban felsoroljuk a rendszerben használt táblázatokat:

|**Tábla neve**|**Elsődleges kulcs**|**Leírás**|
| :-: | :-: | :-: |
|Admin|a\_id|Az admin belépési adatok tárolása|
|Book|b\_id|A könyvek részleteinek tárolása|
|Category|cat\_id|A kategóriák nevének tárolása|
|Contact|c\_id|Ügyfélkapcsolati adatok tárolása|
|Register|r\_id|A regisztrált felhasználók adatai|
|Order|o\_id|A megrendelések részletei|

**Admin tábla:**

|**Mező**|**Típus**|**Leírás**|
| :-: | :-: | :-: |
|a\_id|int(4)|Admin azonosító|
|a\_unm|varchar(30)|Admin felhasználónév|
|a\_pwd|varchar(30)|Admin jelszó|

**Book tábla:**

|**Mező**|**Típus**|**Leírás**|
| :-: | :-: | :-: |
|b\_id|int(10)|Könyv azonosító|
|b\_nm|varchar(50)|Könyv neve|
|b\_cat|int(6)|Könyvkategória azonosító|
|b\_desc|longtext|Könyv leírása|
|b\_price|int(4)|Könyv ára|
|b\_img|varchar(50)|Könyv képének neve|
|b\_time|int(20)|Könyv hozzáadásának ideje|

-----
**3.3 Bemenet/Kimenet tervezés**

**Honlap főoldala**

A könyvesbolt-menedzsment rendszer főoldala a nem bejelentkezett felhasználók számára.

**Kategória kiválasztása**

Például a "Detektív könyvek" kategória kiválasztása.

**Könyvrészletek (Bejelentkezés előtt)**

A látogatók megtekinthetik a könyvek részleteit, de nem adhatják azokat a kosárhoz.

**Bejelentkezési oldal (Látogatók számára)**

A látogatók itt jelentkezhetnek be a rendszerbe.

**Regisztrációs oldal**

Új felhasználók itt regisztrálhatnak.

**Kapcsolat oldal**

Az ügyfelek kapcsolatba léphetnek az adminnal ezen az oldalon.

**4. Fejezet: Tesztelés és implementáció**

**4.1 Használt tesztelési módszerek**

**Fekete doboz tesztelés**

A fekete doboz tesztelés egy szoftvertesztelési módszer, amely az alkalmazás funkcionalitását vizsgálja a specifikációk alapján. Ezt specifikáció alapú tesztelésnek is nevezik. A tesztelés során a tesztelők anélkül vizsgálják az alkalmazás működését, hogy ismernék annak belső szerkezetét vagy kódját.

Ez a módszer alkalmazható minden szoftvertesztelési szintre, mint például az egységtesztelés, az integrációs tesztelés, a rendszer- és átvételi tesztelés.

**Fekete doboz tesztelés előnyei:**

- A tesztek a felhasználó szemszögéből történnek, és segítenek a specifikációkkal kapcsolatos eltérések feltárásában.
- A tesztelőnek nem kell ismernie a programozási nyelveket vagy a szoftver belső működését.

**Fehér doboz tesztelés**

A fehér doboz tesztelés olyan technika, amely a program szerkezetét vizsgálja, és a tesztadatokat a program logikájából vagy kódjából származtatja. A fehér doboz tesztelés más neveken is ismert, mint például az üveg doboz tesztelés, nyitott doboz tesztelés vagy logikavezérelt tesztelés.

A fehér doboz tesztelés során a program belső szerkezetét vizsgáljuk, és arra összpontosítunk, hogy a belső működés a specifikációknak megfelelően történjen.

**Fehér doboz tesztelés előnyei:**

- A tesztelő kénytelen gondosan átgondolni az implementációt.
- Rejtett kódhibákat tár fel.
- Segít betartani a legjobb programozási gyakorlatokat.

**Szürke doboz tesztelés**

A szürke doboz tesztelés egy olyan tesztelési módszer, amely korlátozott információval rendelkezik a rendszer belső működéséről. A szürke doboz tesztelők hozzáférnek a követelmények részletes tervéhez. A tesztek állapotalapú modellek, UML diagramok vagy a célrendszer alapján készülnek.

**4.2 Tesztesetek**

**4.2.1 Admin bejelentkezési adatok**

|**Felhasználónév**|**Jelszó**|
| :-: | :-: |
|Admin|Admin|

**Elvárt eredmény:**

- Ha a mezők üresek, hibaüzenet jelenik meg.
- Ha a jelszó vagy a felhasználónév nem létezik, hibát jelez.

**4.2.2 Felhasználói bejelentkezési adatok**

|**Felhasználónév**|**Jelszó**|
| :-: | :-: |
|Dhaval|Dhaval|

**Elvárt eredmény:**

- Ha a mezők üresek, hibaüzenet jelenik meg.
- Ha a jelszó vagy a felhasználónév nem létezik, hibát jelez.

**4.2.3 Regisztrációs adatok**

|**Felhasználónév**|**Jelszó**|**Teljes név**|**Biztonsági válasz**|
| :-: | :-: | :-: | :-: |
|ÜRES|ÜRES|ÜRES|ÜRES|

**Elvárt eredmény:**

- Ha a mezők üresek, hibaüzenet jelenik meg.
- Ha a jelszó kevesebb mint 8 karakter, hibát jelez.

**4.2.4 Rendelési adatok**

|**Teljes név**|**Cím**|**Telefonszám**|
| :-: | :-: | :-: |
|ÜRES|ÜRES|ÜRES|

**Elvárt eredmény:**

- Ha a mezők üresek, hibaüzenet jelenik meg.
- Ha a telefonszám nem numerikus, hibát jelez.

**Képernyőképek**

**Felhasználói bejelentkezés**

(Felhasználói bejelentkezés képernyője.)

**Admin bejelentkezés**

(Admin bejelentkezés képernyője.)

**Új könyv hozzáadása**

(Könyv hozzáadás képernyője.)

**Felhasználó regisztrációja**

(Felhasználói regisztrációs képernyő.)

-----
**5. Fejezet: Következtetés**

Első pillantásra úgy tűnik, hogy a könyvesbolt-menedzsment rendszer tökéletes, de vannak korlátai, amelyek a következők:

- A rendszer alkalmas könyvkategóriák listázására és könyvek kezelésére.
- Csak egy felhasználó használhatja egyszerre a rendszert.
- Nincs külön szolgáltatási modul a rendszerben.

**5.1 A rendszer korlátai**

**Segítség:**

- Jelenleg a segítségnyújtási funkció nem áll rendelkezésre. A felhasználók nem tudnak segítséget kapni a rendszer használatához.

**Fizetés:**

- Az online fizetési funkció nem érhető el, így a felhasználók nem tudnak online fizetni.

**Többnyelvű támogatás:**

- A rendszer nem támogatja a több nyelvet, így a felhasználók csak egy nyelven dolgozhatnak.

**Biztonsági mentés és visszaállítás:**

- A felhasználók nem tudják biztonsági mentést készíteni vagy adatokat visszaállítani a rendszerben.

**5.2 A rendszer jövőbeni lehetőségei**

**Segítség modul:**

- Ebben a modulban a felhasználók segítséget kaphatnak a rendszer használatáról. A rendszer összes funkciója le van írva ebben a modulban, így a felhasználók könnyebben hozzáférhetnek a rendszerhez.

**Online fizetési modul:**

- A felhasználók a jövőben online fizethetnek a rendszerben. A jövőben az online fizetési funkciót is bevezetjük, hogy a fizetés könnyebb legyen a felhasználók számára.

**Többnyelvű támogatás:**

- A jövőben többnyelvű funkciót is hozzáadunk a rendszerhez, hogy a felhasználók különböző nyelveken is dolgozhassanak.

**5.3 Bibliográfia**

**Használt weboldalak:**

- [www.google.com](http://www.google.com)
- [www.w3schools.com](http://www.w3schools.com)
- [www.stackoverflow.com](http://www.stackoverflow.com)
- [www.quora.com](http://www.quora.com)
- [www.scribd.com](http://www.scribd.com)

**Használt alkalmazások:**

- YouTube
- Solo Learn
- Udemy

