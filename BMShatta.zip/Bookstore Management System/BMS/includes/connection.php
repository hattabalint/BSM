<?php

	$link = mysql_connect("localhost","root","");

	mysql_select_db("bms",$link);

?>